# ELHunter 🕵️‍♂️  
**EVTX Keyword-based Forensic Analysis Tool**

---

## Overview

**ELHunter** is a forensic-oriented CLI tool designed to hunt keyword-based evidence across  
**Windows Event Log (EVTX)** files in a structured and investigator-friendly manner.

This tool focuses on **readability, traceability, and evidential reporting**, making it suitable for  
incident response, digital forensics practice, and security investigations.

> This repository provides **release binaries only**.  
> Source code is intentionally not disclosed.

---

## Author

- **Author** : exyKim  
- **Release Version** : v0.1
- **Release Date** : 2026-01-19

---

## Key Features

- Analyze **single EVTX file** or **entire EVTX folders**
- Case-insensitive keyword hunting
- Real-time console output during analysis
- File-by-file result separation
- Structured forensic report generation (TXT)
- Automatic logging of:
  - User
  - Hostname
  - IP Address
  - Start / End time
  - Elapsed analysis time

---

## How It Works (Logic Overview)

ELHunter operates in a **sequential forensic-safe workflow**:

1. **Input Selection**
   - User selects:
     - Single EVTX file  
     - OR a folder containing multiple EVTX files

2. **Keyword Definition**
   - One or more keywords are provided
   - Matching is performed without case sensitivity

3. **Event Parsing**
   - EVTX records are parsed sequentially
   - XML event data is inspected internally
   - Matching events are immediately reported to the console

4. **Evidence Structuring**
   - Detected events are grouped **per file**
   - Each match is summarized with:
     - Event Time
     - Event ID
     - Key data field (summary)

5. **Forensic Report Generation**
   - Results are consolidated into a **single TXT report**
   - Only files with detected evidence are included
   - Report maintains investigator traceability

---

## Usage

### 1. Launch

```bash
ELHunter.exe
#   E L H u n t e r  
 